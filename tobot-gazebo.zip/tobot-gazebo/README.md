# tobot-gazebo
Gazebo Environment for simulating TOBOT

# Instructions

- Clone the repo
- Build with `catkin_make`
- Then `roslaunch tobot-gazebo toilet1-world.launch`

## To build docker image
### Without Gazebo GUI
1. Open a terminal at `/path/to/tobot-gazebo`.
2. Build the image named `tobot-gazebo` using the `Dockerfile`
	```bash
	docker build -t tobot-gazebo .
	```
3. Create a one-time container (`tbt-gz-cntnr`) by running the command below. `roscore` will automatically start running in the terminal. **If you close this terminal, then the container will be removed.**
	```bash
	docker run --rm -it --name tbt-gz-cntnr tobot-gazebo
	```
4. Attach a terminal to the container and execute your commands
	```bash
	docker exec -it tbt-gz-cntnr /bin/bash
	```

### With Gazebo GUI
1. Open a terminal at `/path/to/tobot-gazebo`.
2. Make the scripts executable:
	```bash
	chmod 755 ./start_cntnr_terminal.sh ./start_cntnr.sh
	```
	These scripts will make it easier to start a container and attach a terminal to the container and execute commands.
	> The `start_cntnr_terminal.sh` script can be executed even for the case of *Without Gazebo GUI*.
3. **This is a one-time step**: Execute the following command:
	```bash
	xhost +local:`docker inspect --format='{{ .Config.Hostname }}' tbt-gz-cntnr`
	```
	This command has been taken from [here][1]. It opens up `xhost` on your host system only for the container having the container ID as `tbt-gz-cntnr`.
4. Execute the following to start a one-time container. `roscore` starts automatically. **If you close this terminal, then the container will be removed.**
	```bash
	./start_cntnr.sh
	```
5. Execute the following everytime you wish to connect a terminal with the container `tbt-gz-cntnr`:
	```bash
	./start_cntnr_terminal.sh
	```


[1]:http://wiki.ros.org/docker/Tutorials/GUI#The_simple_way