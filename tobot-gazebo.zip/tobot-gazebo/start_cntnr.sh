# starts a one-time container with name tbt-gz-cntnr using the image tobot-gazebo
docker run --rm -it --name tbt-gz-cntnr --env=DISPLAY --env=QT_X11_NO_MITSHM=1 --volume=/tmp/.X11-unix:/tmp/.X11-unix:rw tobot-gazebo
